var searchData=
[
  ['addnewlight',['AddNewLight',['../gui__comm_8c.html#ad0a7a379943e760843ba5d5b33de1d21',1,'gui_comm.c']]],
  ['address',['Address',['../struct___l_i_g_h_t___d_a_t_a.html#a66ef61ae5c785f88e6c9057fc31c0c18',1,'_LIGHT_DATA']]]
];
