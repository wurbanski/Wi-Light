var searchData=
[
  ['datetimedlg_2ec',['DateTimeDLG.c',['../_date_time_d_l_g_8c.html',1,'']]]
];
