var searchData=
[
  ['gui_5fcomm_2ec',['gui_comm.c',['../gui__comm_8c.html',1,'']]],
  ['gui_5finitialized',['GUI_Initialized',['../main_8c.html#aa13161ac539bd04c8427b80a14d6f094',1,'main.c']]]
];
