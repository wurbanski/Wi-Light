var searchData=
[
  ['light_5fdata',['LIGHT_DATA',['../gui__comm_8c.html#a6c7e5ddec8cdbf8fd72bed46ea988c7e',1,'gui_comm.c']]]
];
