var searchData=
[
  ['nrf24l01_5fcomm_2ec',['nrf24l01_comm.c',['../nrf24l01__comm_8c.html',1,'']]],
  ['nrf_5fclearstatus',['NRF_ClearStatus',['../nrf24l01__comm_8c.html#aa664d4b045503c223dc2e2ebc55adc6f',1,'nrf24l01_comm.c']]],
  ['nrf_5fconfiguretx',['NRF_ConfigureTX',['../nrf24l01__comm_8c.html#a9c393475d65c11f52781fbb9bf556f58',1,'nrf24l01_comm.c']]],
  ['nrf_5fflushtx',['NRF_FlushTX',['../nrf24l01__comm_8c.html#ae605ecc42071b7b515edd7cd1d9401cd',1,'nrf24l01_comm.c']]],
  ['nrf_5fgetregcommand',['NRF_GetRegCommand',['../nrf24l01__comm_8c.html#ab14c0bdafd883490b085e08a083b663f',1,'nrf24l01_comm.c']]],
  ['nrf_5finit',['NRF_Init',['../nrf24l01__comm_8c.html#a3d562d055e0eb05bf0f74fe34b53321d',1,'nrf24l01_comm.c']]],
  ['nrf_5fpowerdowntx',['NRF_PowerDownTX',['../nrf24l01__comm_8c.html#ae5e171d89fe5719c26d37f12db8bde98',1,'nrf24l01_comm.c']]],
  ['nrf_5fpoweruptx',['NRF_PowerUpTX',['../nrf24l01__comm_8c.html#a7515f0ce603cc795df87cb2149649637',1,'nrf24l01_comm.c']]],
  ['nrf_5freadreg',['NRF_ReadReg',['../nrf24l01__comm_8c.html#ac9746dcf2d7841c9797f6cfd95c32927',1,'nrf24l01_comm.c']]],
  ['nrf_5freadregdata',['NRF_ReadRegData',['../nrf24l01__comm_8c.html#a0552a152546b32e65db7863f192a091f',1,'nrf24l01_comm.c']]],
  ['nrf_5fsend',['NRF_Send',['../nrf24l01__comm_8c.html#a8c7ec8a173a71d17cc70888b14a2813a',1,'nrf24l01_comm.c']]],
  ['nrf_5fwritereg',['NRF_WriteReg',['../nrf24l01__comm_8c.html#afa50fdb081596005163b379526152a31',1,'nrf24l01_comm.c']]],
  ['nrf_5fwriteregdata',['NRF_WriteRegData',['../nrf24l01__comm_8c.html#a91cb62aeb752e0e829aeaf6f105fd6ea',1,'nrf24l01_comm.c']]]
];
