var searchData=
[
  ['reconfigurelight',['ReconfigureLight',['../gui__comm_8c.html#a74cd424c3d51d486647da82f70e66147',1,'gui_comm.c']]],
  ['removelight',['RemoveLight',['../gui__comm_8c.html#aee5a0529f289a1e397a345c35f9d3764',1,'gui_comm.c']]],
  ['reserved',['Reserved',['../struct___l_i_g_h_t___d_a_t_a.html#ac132425a70f39fe07667cecb77969764',1,'_LIGHT_DATA']]]
];
