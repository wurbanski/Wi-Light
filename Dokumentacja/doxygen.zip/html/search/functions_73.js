var searchData=
[
  ['setdatetime',['SetDateTime',['../gui__comm_8c.html#a734a7959c046d768030f951637f59d4a',1,'gui_comm.c']]],
  ['spi_5finitconf',['SPI_InitConf',['../spi__comm_8c.html#a056b3d4e4758d7917573105c4794bb54',1,'spi_comm.c']]],
  ['spi_5fwriteread',['SPI_WriteRead',['../spi__comm_8c.html#addbf634b849688c40c89001f51971f60',1,'spi_comm.c']]],
  ['sram_5finit',['SRAM_Init',['../group___s_t_m324x_g___e_v_a_l___f_s_m_c___s_r_a_m___private___functions.html#gada553a2174ce811261ec6e29f498dc7d',1,'stm32f4xx_discovery_fsmc_sram.c']]],
  ['sram_5freadbuffer',['SRAM_ReadBuffer',['../group___s_t_m324x_g___e_v_a_l___f_s_m_c___s_r_a_m___private___functions.html#ga12c0d78260726cdecb338fc2bc80a92f',1,'stm32f4xx_discovery_fsmc_sram.c']]],
  ['sram_5fwritebuffer',['SRAM_WriteBuffer',['../group___s_t_m324x_g___e_v_a_l___f_s_m_c___s_r_a_m___private___functions.html#ga5259218c1ac17f55223b11cdc3ed4ac3',1,'stm32f4xx_discovery_fsmc_sram.c']]]
];
