var searchData=
[
  ['togglelightmoden',['ToggleLightModeN',['../gui__comm_8c.html#aace1690bd14f2bf6dfe49cc2a83334ea',1,'gui_comm.c']]],
  ['togglelightn',['ToggleLightN',['../gui__comm_8c.html#a94a642797c7e49becfb6fb815dd0d959',1,'gui_comm.c']]]
];
