var searchData=
[
  ['address',['Address',['../struct___l_i_g_h_t___d_a_t_a.html#a66ef61ae5c785f88e6c9057fc31c0c18',1,'_LIGHT_DATA']]]
];
