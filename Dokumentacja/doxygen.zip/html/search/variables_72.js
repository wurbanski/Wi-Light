var searchData=
[
  ['reserved',['Reserved',['../struct___l_i_g_h_t___d_a_t_a.html#ac132425a70f39fe07667cecb77969764',1,'_LIGHT_DATA']]]
];
