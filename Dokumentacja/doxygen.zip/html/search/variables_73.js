var searchData=
[
  ['state',['State',['../struct___l_i_g_h_t___d_a_t_a.html#a9d4426b03ef7d0e8c9f15aed4ad51196',1,'_LIGHT_DATA']]]
];
